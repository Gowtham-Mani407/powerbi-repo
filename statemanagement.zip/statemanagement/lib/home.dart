import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:statemanagement/second.dart';

import 'Listprovider.dart';

class home extends StatefulWidget {
  const home({Key? key}) : super(key: key);

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  @override
  Widget build(BuildContext context) {
    //Build a widget tree while listening to providers. Consumer can be used to listen to providers inside a StatefulWidget or to rebuild as few widgets as possible when a provider updates
    // When the state changes, consumers are notified, and they can update their UI or take other actions accordingly
    return Consumer<listnumprovider>(
      builder: (BuildContext context, providermodel, Widget? child) => Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            providermodel.add();
          },
          child: const Icon(Icons.add),
        ),
        appBar: AppBar(
          title: Text("Provider Management"),
          backgroundColor: Colors.purpleAccent[100],
        ),
        body: Container(
          child: Column(
            children: [
              Text(providermodel.num.last.toString()),
              Expanded(
                child: ListView.builder(
                    itemCount: providermodel.num.length,
                    itemBuilder: (context, index) {
                      return Text(providermodel.num[index].toString());
                    }),
              ),
              ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => second()));
                  },
                  child: Text("Next"))
            ],
          ),
        ),
      ),
    );
  }
}
